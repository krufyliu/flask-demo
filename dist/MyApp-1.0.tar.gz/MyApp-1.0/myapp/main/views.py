from myapp.main import main

@main.route('/')
def index():
  return '<h1>This this main index</h1>'