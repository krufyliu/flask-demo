from myapp.admin import admin

@admin.route('/')
def index():
  return '<h1>This is admin index, static folder: %s</h1>' % admin.static_folder